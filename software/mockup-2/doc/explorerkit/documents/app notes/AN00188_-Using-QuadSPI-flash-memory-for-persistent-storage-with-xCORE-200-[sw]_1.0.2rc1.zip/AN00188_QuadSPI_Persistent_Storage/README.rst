Using QuadSPI flash memory for persistent storage with xCORE-200
================================================================

.. appnote:: AN00188

.. version:: 1.0.2

Summary
-------

This application note demonstrates how to use XFLASH option ``--data`` to
store persistent data within QuadSPI flash memory.

This application note provides an example that uses the boot partition in 
QuadSPI flash memory to store the application and the data partition in QuadSPI 
flash memory to store persistent application data.  Once booted the application 
reads data from the data partition using the xCORE quadflash library and uses 
it to illuminate the LED's in various patterns.

Required tools and libraries
............................

* xTIMEcomposer Tools Suite version 14.0 or later is required.

Required hardware
.................

This application note is designed to run on an XMOS xCORE-200 series device. 

The example code provided with the application has been implemented and tested
on the xCORE-200 explorerKIT core module board but there is no dependancy on 
this board and it can be modified to run on any development board which uses an 
xCORE-200 series device.

Prerequisites
.............

  - This document assumes familiarity with the XMOS xCORE-200 architecture,
    the XMOS tool chain and the xC language. Documentation related to these
    aspects which are not specific to this application note are linked to
    in the *References* appendix.

  - This document assumes familiarity with QuadSPI flash memory, the xCORE 
    quadflash library and the XMOS tool XFLASH.

  - For descriptions of XMOS related terms found in this document please see
    the XMOS Glossary [#]_.

  - The XMOS tools manual contains information regarding the use of xCORE
    devices [#]_.

.. [#] http://www.xmos.com/published/glossary

.. [#] http://www.xmos.com/published/xtimecomposer-user-guide

