Interfacing High Speed ADCs with xCORE
======================================

.. version:: 1.0.2

Summary
-------

The application notes shows how to interface high speed ADCs with xCORE devices. It also gives an overview about the advantages of using xCORE buffered I/O ports, clock blocks and xCONNECT communication channels.

The code associated with this application note povide an example to interface Texas Instruments high speed ADC (ADS7863A) to xCORE devices. The application note contains simulation that shows how the data is sampled by the xCORE device.

Required tools and libraries
............................

* xTIMEcomposer Tools - Version 13.2 

Required hardware
.................

This application note is designed to run using xSIM (XMOS simulator tool). No additional hardware is required to run the example. 

The example code provided with the application has been implemented and tested
using the XMOS simulator tool (xSIM) and can run on any xCORE device.

Prerequisites
.............

  - This document assumes familiarity with the XMOS xCORE architecture, the XMOS tool chain and the xC language. Documentation related to these aspects which are not specific to this application note are linked to in the references appendix.

  - For descriptions of XMOS related terms found in this document please see the XMOS Glossary [#]_.

.. [#] http://www.xmos.com/published/glossary


