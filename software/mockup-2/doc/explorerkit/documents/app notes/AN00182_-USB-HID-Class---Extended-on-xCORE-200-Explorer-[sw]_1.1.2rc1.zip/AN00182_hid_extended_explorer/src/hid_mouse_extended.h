// Copyright (c) 2016, XMOS Ltd, All rights reserved
#ifndef HID_MOUSE_EXTENDED_H_
#define HID_MOUSE_EXTENDED_H_

#include <i2c.h>

struct mouse_input_data {
    int x;
    int y;
    int button_left;
    int button_right;
};

interface mouse_input_if {
    struct mouse_input_data get_input_data();
};

void hid_mouse_extended(chanend chan_ep_hid, client interface mouse_input_if mi_if);
void mouse_input(server interface mouse_input_if mi_if, client interface i2c_master_if i2c);

#endif /* HID_MOUSE_EXTENDED_H_ */
