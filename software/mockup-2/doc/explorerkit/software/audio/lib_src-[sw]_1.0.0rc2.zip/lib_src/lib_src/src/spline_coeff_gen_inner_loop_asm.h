// Copyright (c) 2016, XMOS Ltd, All rights reserved


#ifndef spline_coeff_gen_inner_loop_ASM_H_
#define spline_coeff_gen_inner_loop_ASM_H_

void spline_coeff_gen_inner_loop_asm(int *piPhase0, int *iH, int* piADCoefs, const int n_taps);

#endif
