lib_xcore_c change log
======================

2.0.0
-----

  * Alteration & extension of the API

  * Changes to dependencies:

    - lib_trycatch: Added dependency 1.0.0

    - lib_xassert: Added dependency 2.0.1

1.0.1
-----

  * EVENT_DEFAULT change to EVENT_NONE

1.0.0
-----

  * Initial release

