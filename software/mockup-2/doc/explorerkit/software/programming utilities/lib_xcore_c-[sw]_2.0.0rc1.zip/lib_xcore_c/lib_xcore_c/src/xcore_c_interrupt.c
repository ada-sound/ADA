// Copyright (c) 2016, XMOS Ltd, All rights reserved

#include "xcore_c_interrupt_impl.h"

#include "xcore_c_interrupt.h"
extern xcore_c_error_t interrupt_mask_all(void);
extern xcore_c_error_t interrupt_unmask_all(void);
