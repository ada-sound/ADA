// Copyright (c) 2016, XMOS Ltd, All rights reserved

#include "xcore_c_select.h"
extern xcore_c_error_t select_disable_trigger_all(void);
