lib_trycatch change log
=======================

1.0.0
-----

  * Initial release

