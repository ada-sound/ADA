Logging change log
==================

2.1.0
-----

  * ADDED:    Now supports the %p format specifier
  * CHANGE:   Ignore the case of the format specifiers
  * CHANGE:   Ignore padding and alignment characters

2.0.1
-----

  * CHANGE:   Update to source code license and copyright

2.0.0
-----

  * CHANGE:   Restructured library

