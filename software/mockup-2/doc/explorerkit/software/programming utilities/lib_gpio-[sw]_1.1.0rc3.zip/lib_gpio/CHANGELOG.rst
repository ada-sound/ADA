GPIO library change log
=======================

1.1.0
-----

  * CHANGE: Minor documentation clarifications
  * CHANGE: Update to dependency (lib_xassert moved to 3.0.0)

1.0.1
-----

  * CHANGE: Update to source code license and copyright

1.0.0
-----

  * Initial version

  * Changes to dependencies:

    - lib_xassert: Added dependency 2.0.0

