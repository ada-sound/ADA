Locks library change log
========================

2.0.3
-----

  * RESOLVED: Fixed the software locks when using high priority cores

2.0.2
-----

  * CHANGE: Update to source code license and copyright

2.0.1
-----

  * CHANGE: Update to use lock resource macro from the standard library to
    prevent compile warning

2.0.0
-----

  * CHANGE: Restructured library

