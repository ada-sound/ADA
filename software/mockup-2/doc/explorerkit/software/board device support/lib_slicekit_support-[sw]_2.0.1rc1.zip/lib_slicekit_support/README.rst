sliceKIT board support library
==============================

Summary
-------

The sliceKIT support library for managing the flash port
multiplex on the xCORE sliceKIT core board.

Software version and dependencies
.................................

.. libdeps::
