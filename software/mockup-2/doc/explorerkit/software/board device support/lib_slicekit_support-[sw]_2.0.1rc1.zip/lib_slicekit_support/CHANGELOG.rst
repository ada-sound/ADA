sliceKIT support library change log
===================================

2.0.1
-----

  * Update to source code license and copyright

2.0.0
-----

  * Restructured

1.0.3
-----

  * Moved from sc_util
  * Fix code that assumes tile[0] gets node ide 0

1.0.2
-----

  * Fix module_slicekit_support to work with L16 target

1.0.1
-----

  * No change to slicekit support (changes to sc_util where module used to be)

1.0.0
-----

  * Initial Version

