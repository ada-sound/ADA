Startkit support library change log
===================================

3.0.1
-----

  * Update to source code license and copyright

3.0.0
-----

  * Move the declaration of 'adc_sample' port out of the library.
  * Correct XS1_PORT_4B, XS1_PORT_4A mapping onto SLIDER X and SLIDER Y
  * Alter led interface to use x,y coordinates
  * Alter slider state behaviour

