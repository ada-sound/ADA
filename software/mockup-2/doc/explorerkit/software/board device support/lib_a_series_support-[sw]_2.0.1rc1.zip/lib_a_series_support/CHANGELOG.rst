A-Series support library change log
===================================

2.0.1
-----

  * Update to source code license and copyright

2.0.0
-----

  * Changes to dependencies:

    - lib_logging: Added dependency 2.0.0

    - lib_xassert: Added dependency 2.0.0

