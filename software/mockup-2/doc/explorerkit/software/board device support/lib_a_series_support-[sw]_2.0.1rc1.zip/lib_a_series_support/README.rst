A-Series Support Library
========================

A-Series Support Library
------------------------

This library provides support for accessing the available functionality of the 
XMOS A-Series devices.

Features
........

 * ADC support.
 * Sleep support.
 * Watchdog timer support.

Software version and dependencies
.................................

.. libdeps::
