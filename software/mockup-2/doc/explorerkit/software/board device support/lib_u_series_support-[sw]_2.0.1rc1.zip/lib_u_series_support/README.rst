U-Series Support Library
========================

U-Series Support Library
------------------------

This library provides support for accessing the available functionality of the 
XMOS U-Series devices.

Features
........

 * ADC support.

Software version and dependencies
.................................

.. libdeps::
