// Copyright (c) 2013-2016, XMOS Ltd, All rights reserved
#ifndef _reboot_h_
#define _reboot_h_

void device_reboot(void);

#endif
