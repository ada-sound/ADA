// Copyright (c) 2013-2016, XMOS Ltd, All rights reserved
// Macro that defines a constructor to initiliase the random number generator at startup
#define RANDOM_ENABLE_HW_SEED 1
