// Copyright (c) 2011-2016, XMOS Ltd, All rights reserved
#include "default_avb_conf.h"

#define NUM_ETHERNET_PORTS 1

#define NUM_ETHERNET_MASTER_PORTS 1

#define ETHERNET_SUPPORT_HP_QUEUES 1

#define ETHERNET_MAX_ETHERTYPE_FILTERS 3

