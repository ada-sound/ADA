// Copyright (c) 2016, XMOS Ltd, All rights reserved

// Set this define to 1 if you want the web server to use flash
#define WEB_SERVER_USE_FLASH 0

// Set this define to 1 if you want the web server to access flash
// from a separate task to the tcp handler
#define WEB_SERVER_USE_SEPARATE_FLASH_TASK 0

// These defines to refer to an array of
// flash identifiers for the webserver to use
#define WEB_SERVER_FLASH_DEVICES flash_devices

#define WEB_SERVER_NUM_FLASH_DEVICES 1

// Declare any functions that are used in the webpages here...


