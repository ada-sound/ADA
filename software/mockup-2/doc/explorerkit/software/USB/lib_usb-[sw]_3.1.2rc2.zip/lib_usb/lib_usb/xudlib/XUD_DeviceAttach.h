// Copyright (c) 2016, XMOS Ltd, All rights reserved


/** @brief Does high speed device attach
  * @return non-zero for error
  **/
int XUD_DeviceAttachHS(XUD_PwrConfig p);

