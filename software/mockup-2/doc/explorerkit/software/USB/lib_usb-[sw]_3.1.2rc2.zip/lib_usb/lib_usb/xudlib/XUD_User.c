// Copyright (c) 2016, XMOS Ltd, All rights reserved

/* User functions to be overridden by app */
__attribute__((weak))
void XUD_UserSuspend()
{
    return;
}



/* User functions to be overridden by app */
__attribute__((weak))
void XUD_UserResume()
{
    return;
}
