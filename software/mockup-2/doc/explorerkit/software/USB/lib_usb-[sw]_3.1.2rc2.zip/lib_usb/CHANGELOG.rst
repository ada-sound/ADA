USB library change log
======================

3.1.2
-----

  * Resolved initialisation failure on U-series devices

3.1.1
-----

  * Update to source code license and copyright

3.1.0
-----

  * ADDED:     Bulk read benchmark to AN00136
  * CHANGE:    Throughput performance of bulk example (AN00136) dramatically
    improved using async API of host libusb
  * CHANGE:    Standard descriptor structs now packed (and only available from
    C)
  * RESOLVED:  Initialisation issue on xCORE-200

3.0.0
-----

  * Initial version of lib_usb. The code has been moved over from the old
    module_xud (sc_xud), module_usb (sc_usb) and module_usb_shared (sc_usb)
    repositories. Please see those repos for old changes.
  * Split XUD_Manager in separate xud functions for U/X200 series and L series
    for a simpler interface.
  * Removed the EpTypeTable argument from XUD_Manager. Now endpoints register
    their type via an extra argument to XUD_InitEp. This makes multiple
    endpoints programs easier to maintain.

  * Changes to dependencies:

    - lib_gpio: Added dependency 1.0.0

    - lib_logging: Added dependency 2.0.0

    - lib_xassert: Added dependency 2.0.0

