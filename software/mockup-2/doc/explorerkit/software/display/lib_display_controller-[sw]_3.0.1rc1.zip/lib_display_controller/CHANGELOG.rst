Display controller library change log
=====================================

3.0.1
-----

  * Update to source code license and copyright

3.0.0
-----

  * Consolidated version, major rework from previous display controller
    components

  * Changes to dependencies:

    - lib_lcd: Added dependency 3.0.0

    - lib_sdram: Added dependency 3.0.0

